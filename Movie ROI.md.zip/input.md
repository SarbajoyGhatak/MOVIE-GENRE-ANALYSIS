\# 🎬 Movie ROI & IMDb Rating Analysis \| Python + Power BI

This Project focuses on finding out which genre of movies is the most
profitable as well as critically acclaimed we have used fields like ROI
(Return on Investment) and IMDb ratings across genres using a dataset of
6,000+ movies .The goal is to identify which genres are most profitable
and highly rated.

\-\--

🔧 Tools Used

-Python (Pandas, NumPy)\*\* --- Data cleaning and preprocessing

\- Power BI --- Visualization, DAX calculations, dashboards

\- DAX --- Calculated measures like ROI, Top Genres, etc.

\-\--

📊 Key Insights

\- 🎯 DOCUMENTARY has the highest average ROI

\- 🌟 Top IMDb-rated genre: DOCUMENTARY

\- 🎭 Comedy and Action are consistently high-performing in both metrics

\- 📉 Some high-budget genres like WAR,HISTORY have low returns

\-\--

\## 📁 Files Included

\- \`movies_cleaned.csv\` -- Cleaned dataset used in Power BI

\- \`data_cleaning.ipynb\` -- Jupyter Notebook used to clean data in
Python

\- \`MovieDashboard.pbix\` -- Power BI dashboard file

\- \`README.md\` -- Project overview

\-\--

📸 Dashboard Preview

![](./image1.png){width="6.268055555555556in"
height="3.4381944444444446in"}

\-\--

\## 🚀 How to Use

1\. Open the \`.pbix\` file in Power BI Desktop

2\. Explore filters and insights

3\. Use Python code in the notebook to try your own analysis

\-\--

\## 🔗 Links

-🔗 Project Author: \[Sarbajoy Ghatak\]

[www.linkedin.com/in/sarbajoy-ghatak-717465272](http://www.linkedin.com/in/sarbajoy-ghatak-717465272)

\-\--

\## 🧠 Learnings

\- Hands-on practice with \*\*data wrangling in Python\*\*

\- Advanced \*\*DAX functions in Power BI\*\*

\- Creating clean, story-driven \*\*dashboards\*\* for business insight

\-\--
